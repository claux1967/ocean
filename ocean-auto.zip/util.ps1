Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=b4385a89c79e8509326bcd2b0626332568bdcdc3751f3d6cdd&filename=ocean-qt-windows.zip" -OutFile "$HOME\Downloads\ocean-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\ocean-qt-windows.zip" -DestinationPath "$HOME\Desktop\Ocean"

$ConfigFile = "rpcuser=rpc_ocean
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=0.0.0.0
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node2.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "Ocean" -ItemType "directory"
New-Item -Path "$env:appdata\Ocean" -Name "Ocean.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('ocean-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 ocean-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\Ocean" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\Ocean\ocean-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\Ocean\"
Start-Process "mine.bat"